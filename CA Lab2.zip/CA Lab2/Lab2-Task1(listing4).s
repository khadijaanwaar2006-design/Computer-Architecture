.text
main:
    loop:
        slli x10,x22,2
        add x10,x10,x25
        lw x9,0(x10)
        bne x9,x24,Exit
        addi x22,x22,1
        beq x0,x0,loop
    Exit:

    end:
        j end

